﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EXAMLIST
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        DataGridView1 = New DataGridView()
        Panel1 = New Panel()
        cmbCourse = New ComboBox()
        btnSearch = New Button()
        txtSearch = New TextBox()
        cmbAssessmenttype = New ComboBox()
        colQuestion = New DataGridViewTextBoxColumn()
        colOptionA = New DataGridViewTextBoxColumn()
        colOptionB = New DataGridViewTextBoxColumn()
        colOptionC = New DataGridViewTextBoxColumn()
        colOptionD = New DataGridViewTextBoxColumn()
        colCorrectAnswer = New DataGridViewTextBoxColumn()
        colEdit = New DataGridViewImageColumn()
        colDelete = New DataGridViewImageColumn()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' DataGridView1
        ' 
        DataGridView1.AllowUserToAddRows = False
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Columns.AddRange(New DataGridViewColumn() {colQuestion, colOptionA, colOptionB, colOptionC, colOptionD, colCorrectAnswer, colEdit, colDelete})
        DataGridView1.Location = New Point(12, 57)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.Size = New Size(745, 299)
        DataGridView1.TabIndex = 0
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Maroon
        Panel1.Controls.Add(cmbCourse)
        Panel1.Controls.Add(btnSearch)
        Panel1.Controls.Add(txtSearch)
        Panel1.Controls.Add(cmbAssessmenttype)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(769, 45)
        Panel1.TabIndex = 1
        ' 
        ' cmbCourse
        ' 
        cmbCourse.FormattingEnabled = True
        cmbCourse.Location = New Point(601, 11)
        cmbCourse.Name = "cmbCourse"
        cmbCourse.Size = New Size(156, 23)
        cmbCourse.TabIndex = 5
        ' 
        ' btnSearch
        ' 
        btnSearch.BackColor = Color.WhiteSmoke
        btnSearch.FlatAppearance.BorderSize = 0
        btnSearch.FlatAppearance.MouseDownBackColor = Color.LightGray
        btnSearch.FlatStyle = FlatStyle.Flat
        btnSearch.Image = My.Resources.Resources.blackSearch
        btnSearch.Location = New Point(35, 9)
        btnSearch.Name = "btnSearch"
        btnSearch.Size = New Size(42, 26)
        btnSearch.TabIndex = 4
        btnSearch.UseVisualStyleBackColor = False
        ' 
        ' txtSearch
        ' 
        txtSearch.BackColor = Color.WhiteSmoke
        txtSearch.BorderStyle = BorderStyle.None
        txtSearch.Font = New Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtSearch.ForeColor = Color.Black
        txtSearch.Location = New Point(76, 9)
        txtSearch.Multiline = True
        txtSearch.Name = "txtSearch"
        txtSearch.Size = New Size(236, 26)
        txtSearch.TabIndex = 3
        ' 
        ' cmbAssessmenttype
        ' 
        cmbAssessmenttype.FormattingEnabled = True
        cmbAssessmenttype.Location = New Point(435, 11)
        cmbAssessmenttype.Name = "cmbAssessmenttype"
        cmbAssessmenttype.Size = New Size(156, 23)
        cmbAssessmenttype.TabIndex = 0
        ' 
        ' colQuestion
        ' 
        colQuestion.HeaderText = "Question"
        colQuestion.MinimumWidth = 6
        colQuestion.Name = "colQuestion"
        colQuestion.Width = 115
        ' 
        ' colOptionA
        ' 
        colOptionA.HeaderText = "Option A"
        colOptionA.MinimumWidth = 6
        colOptionA.Name = "colOptionA"
        colOptionA.Width = 114
        ' 
        ' colOptionB
        ' 
        colOptionB.HeaderText = "Option B"
        colOptionB.MinimumWidth = 6
        colOptionB.Name = "colOptionB"
        colOptionB.Width = 115
        ' 
        ' colOptionC
        ' 
        colOptionC.HeaderText = "Option C"
        colOptionC.MinimumWidth = 6
        colOptionC.Name = "colOptionC"
        colOptionC.Width = 114
        ' 
        ' colOptionD
        ' 
        colOptionD.HeaderText = "Option D"
        colOptionD.MinimumWidth = 6
        colOptionD.Name = "colOptionD"
        colOptionD.Width = 109
        ' 
        ' colCorrectAnswer
        ' 
        colCorrectAnswer.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        colCorrectAnswer.HeaderText = "Correct Answer"
        colCorrectAnswer.MinimumWidth = 6
        colCorrectAnswer.Name = "colCorrectAnswer"
        colCorrectAnswer.Width = 113
        ' 
        ' colEdit
        ' 
        colEdit.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        colEdit.HeaderText = "Edit"
        colEdit.MinimumWidth = 6
        colEdit.Name = "colEdit"
        colEdit.Width = 33
        ' 
        ' colDelete
        ' 
        colDelete.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        colDelete.HeaderText = "Delete"
        colDelete.MinimumWidth = 6
        colDelete.Name = "colDelete"
        colDelete.Width = 46
        ' 
        ' EXAMLIST
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(769, 368)
        Controls.Add(Panel1)
        Controls.Add(DataGridView1)
        FormBorderStyle = FormBorderStyle.None
        Name = "EXAMLIST"
        StartPosition = FormStartPosition.CenterScreen
        Text = "EXAMLIST"
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Panel1 As Panel
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents cmbAssessmenttype As ComboBox
    Friend WithEvents cmbCourse As ComboBox
    Friend WithEvents btnSearch As Button
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents colQuestion As DataGridViewTextBoxColumn
    Friend WithEvents colOptionA As DataGridViewTextBoxColumn
    Friend WithEvents colOptionB As DataGridViewTextBoxColumn
    Friend WithEvents colOptionC As DataGridViewTextBoxColumn
    Friend WithEvents colOptionD As DataGridViewTextBoxColumn
    Friend WithEvents colCorrectAnswer As DataGridViewTextBoxColumn
    Friend WithEvents colEdit As DataGridViewImageColumn
    Friend WithEvents colDelete As DataGridViewImageColumn
End Class
