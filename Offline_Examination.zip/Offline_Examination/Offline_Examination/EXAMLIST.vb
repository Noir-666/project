﻿Public Class EXAMLIST
    Private Sub txtSearch_MouseHover(sender As Object, e As EventArgs) Handles txtSearch.MouseHover
        txtSearch.BackColor = Color.Gainsboro
    End Sub

    Private Sub txtSearch_MouseLeave(sender As Object, e As EventArgs) Handles txtSearch.MouseLeave
        txtSearch.BackColor = Color.White
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub
End Class