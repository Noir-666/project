﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SECTIONLIST
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        btnSearch = New Button()
        txtSearch = New TextBox()
        btnAdd = New Button()
        DataGridView1 = New DataGridView()
        colID = New DataGridViewTextBoxColumn()
        colSection = New DataGridViewTextBoxColumn()
        colCourseCode = New DataGridViewTextBoxColumn()
        colEdit = New DataGridViewImageColumn()
        ColDelete = New DataGridViewImageColumn()
        Panel1.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Maroon
        Panel1.Controls.Add(btnSearch)
        Panel1.Controls.Add(txtSearch)
        Panel1.Controls.Add(btnAdd)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(602, 45)
        Panel1.TabIndex = 2
        ' 
        ' btnSearch
        ' 
        btnSearch.BackColor = Color.WhiteSmoke
        btnSearch.FlatAppearance.BorderSize = 0
        btnSearch.FlatAppearance.MouseDownBackColor = Color.LightGray
        btnSearch.FlatStyle = FlatStyle.Flat
        btnSearch.Image = My.Resources.Resources.blackSearch
        btnSearch.Location = New Point(25, 8)
        btnSearch.Name = "btnSearch"
        btnSearch.Size = New Size(42, 26)
        btnSearch.TabIndex = 2
        btnSearch.UseVisualStyleBackColor = False
        ' 
        ' txtSearch
        ' 
        txtSearch.BackColor = Color.WhiteSmoke
        txtSearch.BorderStyle = BorderStyle.None
        txtSearch.Font = New Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtSearch.ForeColor = Color.Black
        txtSearch.Location = New Point(66, 8)
        txtSearch.Multiline = True
        txtSearch.Name = "txtSearch"
        txtSearch.Size = New Size(236, 26)
        txtSearch.TabIndex = 1
        ' 
        ' btnAdd
        ' 
        btnAdd.FlatAppearance.BorderSize = 0
        btnAdd.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(179), CByte(57), CByte(57))
        btnAdd.FlatStyle = FlatStyle.Flat
        btnAdd.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnAdd.ForeColor = Color.White
        btnAdd.Image = My.Resources.Resources.icons8_add_16
        btnAdd.ImageAlign = ContentAlignment.MiddleRight
        btnAdd.Location = New Point(521, 7)
        btnAdd.Name = "btnAdd"
        btnAdd.Size = New Size(67, 30)
        btnAdd.TabIndex = 0
        btnAdd.Text = "Add"
        btnAdd.UseVisualStyleBackColor = True
        ' 
        ' DataGridView1
        ' 
        DataGridView1.AllowUserToAddRows = False
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Columns.AddRange(New DataGridViewColumn() {colID, colSection, colCourseCode, colEdit, ColDelete})
        DataGridView1.Location = New Point(13, 57)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.ReadOnly = True
        DataGridView1.Size = New Size(575, 277)
        DataGridView1.TabIndex = 3
        ' 
        ' colID
        ' 
        colID.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        colID.HeaderText = "ID"
        colID.Name = "colID"
        colID.ReadOnly = True
        colID.Width = 43
        ' 
        ' colSection
        ' 
        colSection.HeaderText = "Section"
        colSection.MinimumWidth = 6
        colSection.Name = "colSection"
        colSection.ReadOnly = True
        colSection.Width = 354
        ' 
        ' colCourseCode
        ' 
        colCourseCode.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        colCourseCode.HeaderText = "Course Code"
        colCourseCode.MinimumWidth = 6
        colCourseCode.Name = "colCourseCode"
        colCourseCode.ReadOnly = True
        ' 
        ' colEdit
        ' 
        colEdit.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        colEdit.HeaderText = "Edit"
        colEdit.MinimumWidth = 6
        colEdit.Name = "colEdit"
        colEdit.ReadOnly = True
        colEdit.Width = 33
        ' 
        ' ColDelete
        ' 
        ColDelete.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        ColDelete.HeaderText = "Delete"
        ColDelete.MinimumWidth = 6
        ColDelete.Name = "ColDelete"
        ColDelete.ReadOnly = True
        ColDelete.Width = 46
        ' 
        ' SECTIONLIST
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(602, 349)
        Controls.Add(DataGridView1)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        Name = "SECTIONLIST"
        StartPosition = FormStartPosition.CenterScreen
        Text = "SECTIONLIST"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnSearch As Button
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents colID As DataGridViewTextBoxColumn
    Friend WithEvents colSection As DataGridViewTextBoxColumn
    Friend WithEvents colCourseCode As DataGridViewTextBoxColumn
    Friend WithEvents colEdit As DataGridViewImageColumn
    Friend WithEvents ColDelete As DataGridViewImageColumn
End Class
