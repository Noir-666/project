﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class QUESTIONLIST
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        btnSearch = New Button()
        txtSearch = New TextBox()
        btnAdd = New Button()
        DataGridView1 = New DataGridView()
        questionID = New DataGridViewTextBoxColumn()
        Question = New DataGridViewTextBoxColumn()
        optionA = New DataGridViewTextBoxColumn()
        optionB = New DataGridViewTextBoxColumn()
        optionC = New DataGridViewTextBoxColumn()
        optionD = New DataGridViewTextBoxColumn()
        CorrectAnswer = New DataGridViewTextBoxColumn()
        colAssessmentType = New DataGridViewTextBoxColumn()
        colCourseCode = New DataGridViewTextBoxColumn()
        edit = New DataGridViewImageColumn()
        delete = New DataGridViewImageColumn()
        view = New DataGridViewImageColumn()
        Panel1.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Maroon
        Panel1.Controls.Add(btnSearch)
        Panel1.Controls.Add(txtSearch)
        Panel1.Controls.Add(btnAdd)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(749, 45)
        Panel1.TabIndex = 2
        ' 
        ' btnSearch
        ' 
        btnSearch.BackColor = Color.WhiteSmoke
        btnSearch.FlatAppearance.BorderSize = 0
        btnSearch.FlatAppearance.MouseDownBackColor = Color.LightGray
        btnSearch.FlatStyle = FlatStyle.Flat
        btnSearch.Image = My.Resources.Resources.blackSearch
        btnSearch.Location = New Point(23, 8)
        btnSearch.Name = "btnSearch"
        btnSearch.Size = New Size(42, 26)
        btnSearch.TabIndex = 2
        btnSearch.UseVisualStyleBackColor = False
        ' 
        ' txtSearch
        ' 
        txtSearch.BackColor = Color.WhiteSmoke
        txtSearch.BorderStyle = BorderStyle.None
        txtSearch.Font = New Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtSearch.ForeColor = Color.Black
        txtSearch.Location = New Point(64, 8)
        txtSearch.Multiline = True
        txtSearch.Name = "txtSearch"
        txtSearch.Size = New Size(236, 26)
        txtSearch.TabIndex = 1
        ' 
        ' btnAdd
        ' 
        btnAdd.FlatAppearance.BorderSize = 0
        btnAdd.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(179), CByte(57), CByte(57))
        btnAdd.FlatStyle = FlatStyle.Flat
        btnAdd.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnAdd.ForeColor = Color.White
        btnAdd.Image = My.Resources.Resources.icons8_add_16
        btnAdd.ImageAlign = ContentAlignment.MiddleRight
        btnAdd.Location = New Point(659, 7)
        btnAdd.Name = "btnAdd"
        btnAdd.Size = New Size(67, 30)
        btnAdd.TabIndex = 0
        btnAdd.Text = "Add"
        btnAdd.UseVisualStyleBackColor = True
        ' 
        ' DataGridView1
        ' 
        DataGridView1.AllowUserToAddRows = False
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Columns.AddRange(New DataGridViewColumn() {questionID, Question, optionA, optionB, optionC, optionD, CorrectAnswer, colAssessmentType, colCourseCode, edit, delete, view})
        DataGridView1.Location = New Point(12, 57)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.ReadOnly = True
        DataGridView1.Size = New Size(725, 246)
        DataGridView1.TabIndex = 3
        ' 
        ' questionID
        ' 
        questionID.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        questionID.HeaderText = "Question ID"
        questionID.Name = "questionID"
        questionID.Width = 94
        ' 
        ' Question
        ' 
        Question.HeaderText = "Question"
        Question.MinimumWidth = 6
        Question.Name = "Question"
        Question.Width = 165
        ' 
        ' optionA
        ' 
        optionA.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        optionA.HeaderText = "A"
        optionA.MinimumWidth = 6
        optionA.Name = "optionA"
        optionA.Width = 40
        ' 
        ' optionB
        ' 
        optionB.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        optionB.HeaderText = "B"
        optionB.MinimumWidth = 6
        optionB.Name = "optionB"
        optionB.Width = 39
        ' 
        ' optionC
        ' 
        optionC.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        optionC.HeaderText = "C"
        optionC.MinimumWidth = 6
        optionC.Name = "optionC"
        optionC.Width = 40
        ' 
        ' optionD
        ' 
        optionD.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        optionD.HeaderText = "D"
        optionD.MinimumWidth = 6
        optionD.Name = "optionD"
        optionD.Width = 40
        ' 
        ' CorrectAnswer
        ' 
        CorrectAnswer.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        CorrectAnswer.HeaderText = "Correct Answer"
        CorrectAnswer.MinimumWidth = 6
        CorrectAnswer.Name = "CorrectAnswer"
        CorrectAnswer.Width = 113
        ' 
        ' colAssessmentType
        ' 
        colAssessmentType.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        colAssessmentType.HeaderText = "Assessment Type"
        colAssessmentType.MinimumWidth = 6
        colAssessmentType.Name = "colAssessmentType"
        colAssessmentType.Width = 112
        ' 
        ' colCourseCode
        ' 
        colCourseCode.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        colCourseCode.HeaderText = "CourseCode"
        colCourseCode.MinimumWidth = 6
        colCourseCode.Name = "colCourseCode"
        colCourseCode.Width = 97
        ' 
        ' edit
        ' 
        edit.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        edit.HeaderText = "Edit"
        edit.MinimumWidth = 6
        edit.Name = "edit"
        edit.Width = 33
        ' 
        ' delete
        ' 
        delete.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        delete.HeaderText = "Delete"
        delete.MinimumWidth = 6
        delete.Name = "delete"
        delete.Width = 46
        ' 
        ' view
        ' 
        view.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        view.HeaderText = "View"
        view.MinimumWidth = 6
        view.Name = "view"
        view.Width = 38
        ' 
        ' QUESTIONLIST
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(749, 315)
        Controls.Add(DataGridView1)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        Name = "QUESTIONLIST"
        StartPosition = FormStartPosition.CenterScreen
        Text = "QUESTIONLIST"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnSearch As Button
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents questionID As DataGridViewTextBoxColumn
    Friend WithEvents Question As DataGridViewTextBoxColumn
    Friend WithEvents optionA As DataGridViewTextBoxColumn
    Friend WithEvents optionB As DataGridViewTextBoxColumn
    Friend WithEvents optionC As DataGridViewTextBoxColumn
    Friend WithEvents optionD As DataGridViewTextBoxColumn
    Friend WithEvents CorrectAnswer As DataGridViewTextBoxColumn
    Friend WithEvents colAssessmentType As DataGridViewTextBoxColumn
    Friend WithEvents colCourseCode As DataGridViewTextBoxColumn
    Friend WithEvents edit As DataGridViewImageColumn
    Friend WithEvents delete As DataGridViewImageColumn
    Friend WithEvents view As DataGridViewImageColumn
End Class
