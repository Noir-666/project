﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class QUESTIONS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        lblQuestion = New Label()
        lblA = New Label()
        lblB = New Label()
        lblC = New Label()
        lblD = New Label()
        lblAnswer = New Label()
        cmbAssessmentType = New ComboBox()
        cmbCourse = New ComboBox()
        txtQuestions = New TextBox()
        txtA = New TextBox()
        txtB = New TextBox()
        txtC = New TextBox()
        txtD = New TextBox()
        txtAnswer = New TextBox()
        time = New DateTimePicker()
        btnBack = New Button()
        btnSave = New Button()
        btnExit = New Button()
        lblCourse = New Label()
        lblAssessmentType = New Label()
        lblCourseCode = New Label()
        SuspendLayout()
        ' 
        ' lblQuestion
        ' 
        lblQuestion.AutoSize = True
        lblQuestion.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblQuestion.Location = New Point(126, 110)
        lblQuestion.Name = "lblQuestion"
        lblQuestion.Size = New Size(63, 15)
        lblQuestion.TabIndex = 2
        lblQuestion.Text = "Question :"
        ' 
        ' lblA
        ' 
        lblA.AutoSize = True
        lblA.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblA.Location = New Point(171, 174)
        lblA.Name = "lblA"
        lblA.Size = New Size(18, 15)
        lblA.TabIndex = 3
        lblA.Text = "A."
        ' 
        ' lblB
        ' 
        lblB.AutoSize = True
        lblB.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblB.Location = New Point(171, 204)
        lblB.Name = "lblB"
        lblB.Size = New Size(18, 15)
        lblB.TabIndex = 4
        lblB.Text = "B."
        ' 
        ' lblC
        ' 
        lblC.AutoSize = True
        lblC.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblC.Location = New Point(171, 234)
        lblC.Name = "lblC"
        lblC.Size = New Size(17, 15)
        lblC.TabIndex = 5
        lblC.Text = "C."
        ' 
        ' lblD
        ' 
        lblD.AutoSize = True
        lblD.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblD.Location = New Point(170, 264)
        lblD.Name = "lblD"
        lblD.Size = New Size(18, 15)
        lblD.TabIndex = 6
        lblD.Text = "D."
        ' 
        ' lblAnswer
        ' 
        lblAnswer.AutoSize = True
        lblAnswer.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblAnswer.Location = New Point(136, 302)
        lblAnswer.Name = "lblAnswer"
        lblAnswer.Size = New Size(55, 15)
        lblAnswer.TabIndex = 7
        lblAnswer.Text = "Answer :"
        ' 
        ' cmbAssessmentType
        ' 
        cmbAssessmentType.FormattingEnabled = True
        cmbAssessmentType.Location = New Point(195, 40)
        cmbAssessmentType.Name = "cmbAssessmentType"
        cmbAssessmentType.Size = New Size(226, 23)
        cmbAssessmentType.TabIndex = 8
        ' 
        ' cmbCourse
        ' 
        cmbCourse.FormattingEnabled = True
        cmbCourse.Location = New Point(195, 70)
        cmbCourse.Name = "cmbCourse"
        cmbCourse.Size = New Size(226, 23)
        cmbCourse.TabIndex = 9
        ' 
        ' txtQuestions
        ' 
        txtQuestions.Location = New Point(195, 107)
        txtQuestions.Multiline = True
        txtQuestions.Name = "txtQuestions"
        txtQuestions.Size = New Size(399, 57)
        txtQuestions.TabIndex = 10
        ' 
        ' txtA
        ' 
        txtA.Location = New Point(195, 170)
        txtA.Name = "txtA"
        txtA.Size = New Size(399, 23)
        txtA.TabIndex = 11
        ' 
        ' txtB
        ' 
        txtB.Location = New Point(195, 200)
        txtB.Name = "txtB"
        txtB.Size = New Size(399, 23)
        txtB.TabIndex = 12
        ' 
        ' txtC
        ' 
        txtC.Location = New Point(194, 229)
        txtC.Name = "txtC"
        txtC.Size = New Size(399, 23)
        txtC.TabIndex = 14
        ' 
        ' txtD
        ' 
        txtD.Location = New Point(194, 258)
        txtD.Name = "txtD"
        txtD.Size = New Size(399, 23)
        txtD.TabIndex = 15
        ' 
        ' txtAnswer
        ' 
        txtAnswer.Location = New Point(194, 297)
        txtAnswer.Name = "txtAnswer"
        txtAnswer.Size = New Size(189, 23)
        txtAnswer.TabIndex = 16
        ' 
        ' time
        ' 
        time.Location = New Point(389, 296)
        time.Name = "time"
        time.Size = New Size(90, 23)
        time.TabIndex = 24
        ' 
        ' btnBack
        ' 
        btnBack.BackColor = Color.Transparent
        btnBack.FlatAppearance.BorderColor = Color.DarkGray
        btnBack.FlatAppearance.MouseOverBackColor = Color.LightGray
        btnBack.FlatStyle = FlatStyle.Flat
        btnBack.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnBack.Location = New Point(228, 335)
        btnBack.Name = "btnBack"
        btnBack.Size = New Size(75, 27)
        btnBack.TabIndex = 25
        btnBack.Text = "Back"
        btnBack.UseVisualStyleBackColor = False
        ' 
        ' btnSave
        ' 
        btnSave.BackColor = Color.Transparent
        btnSave.FlatAppearance.BorderColor = Color.DarkGray
        btnSave.FlatAppearance.MouseOverBackColor = Color.LightGray
        btnSave.FlatStyle = FlatStyle.Flat
        btnSave.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnSave.Location = New Point(346, 335)
        btnSave.Name = "btnSave"
        btnSave.Size = New Size(75, 27)
        btnSave.TabIndex = 26
        btnSave.Text = "Save"
        btnSave.UseVisualStyleBackColor = False
        ' 
        ' btnExit
        ' 
        btnExit.BackColor = Color.Transparent
        btnExit.FlatAppearance.BorderColor = Color.DarkGray
        btnExit.FlatAppearance.MouseOverBackColor = Color.LightGray
        btnExit.FlatStyle = FlatStyle.Flat
        btnExit.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnExit.Location = New Point(463, 335)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(75, 27)
        btnExit.TabIndex = 27
        btnExit.Text = "Next"
        btnExit.UseVisualStyleBackColor = False
        ' 
        ' lblCourse
        ' 
        lblCourse.AutoSize = True
        lblCourse.BackColor = SystemColors.Control
        lblCourse.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblCourse.ForeColor = Color.Black
        lblCourse.Location = New Point(140, 73)
        lblCourse.Name = "lblCourse"
        lblCourse.Size = New Size(51, 15)
        lblCourse.TabIndex = 1
        lblCourse.Text = "Course :"
        ' 
        ' lblAssessmentType
        ' 
        lblAssessmentType.AutoSize = True
        lblAssessmentType.BackColor = SystemColors.Control
        lblAssessmentType.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblAssessmentType.ForeColor = Color.Black
        lblAssessmentType.Location = New Point(46, 43)
        lblAssessmentType.Name = "lblAssessmentType"
        lblAssessmentType.Size = New Size(145, 15)
        lblAssessmentType.TabIndex = 0
        lblAssessmentType.Text = "Select Assessment Type :"
        ' 
        ' lblCourseCode
        ' 
        lblCourseCode.AutoSize = True
        lblCourseCode.BackColor = SystemColors.Control
        lblCourseCode.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblCourseCode.ForeColor = Color.Black
        lblCourseCode.Location = New Point(503, 73)
        lblCourseCode.Name = "lblCourseCode"
        lblCourseCode.Size = New Size(35, 15)
        lblCourseCode.TabIndex = 2
        lblCourseCode.Text = "Code"
        ' 
        ' QUESTIONS
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(656, 381)
        Controls.Add(lblCourseCode)
        Controls.Add(btnExit)
        Controls.Add(lblCourse)
        Controls.Add(lblAssessmentType)
        Controls.Add(btnSave)
        Controls.Add(btnBack)
        Controls.Add(time)
        Controls.Add(txtAnswer)
        Controls.Add(txtD)
        Controls.Add(txtC)
        Controls.Add(txtB)
        Controls.Add(txtA)
        Controls.Add(txtQuestions)
        Controls.Add(cmbCourse)
        Controls.Add(cmbAssessmentType)
        Controls.Add(lblAnswer)
        Controls.Add(lblD)
        Controls.Add(lblC)
        Controls.Add(lblB)
        Controls.Add(lblA)
        Controls.Add(lblQuestion)
        FormBorderStyle = FormBorderStyle.None
        Name = "QUESTIONS"
        StartPosition = FormStartPosition.CenterScreen
        Text = "QUESTIONS"
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents lblQuestion As Label
    Friend WithEvents lblA As Label
    Friend WithEvents lblB As Label
    Friend WithEvents lblC As Label
    Friend WithEvents lblD As Label
    Friend WithEvents lblAnswer As Label
    Friend WithEvents cmbAssessmentType As ComboBox
    Friend WithEvents cmbCourse As ComboBox
    Friend WithEvents txtQuestions As TextBox
    Friend WithEvents txtA As TextBox
    Friend WithEvents txtB As TextBox
    Friend WithEvents txtC As TextBox
    Friend WithEvents txtD As TextBox
    Friend WithEvents txtAnswer As TextBox
    Friend WithEvents time As DateTimePicker
    Friend WithEvents btnBack As Button
    Friend WithEvents btnSave As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblCourse As Label
    Friend WithEvents lblAssessmentType As Label
    Friend WithEvents lblCourseCode As Label
End Class
