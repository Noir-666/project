﻿Public Class Section
    Private Sub txtSection_MouseHover(sender As Object, e As EventArgs) Handles txtSection.MouseHover
        txtSection.BackColor = Color.Gainsboro
    End Sub

    Private Sub txtSection_MouseLeave(sender As Object, e As EventArgs) Handles txtSection.MouseLeave
        txtSection.BackColor = Color.White
    End Sub

End Class