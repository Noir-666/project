﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ASSESSMENT
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        lblAssessmentType = New Label()
        cmbAssessment = New ComboBox()
        cmbStudent = New ComboBox()
        lblStudentCourse = New Label()
        cmbCourse = New ComboBox()
        lblCourseCode = New Label()
        btnBack = New Button()
        Button1 = New Button()
        SuspendLayout()
        ' 
        ' lblAssessmentType
        ' 
        lblAssessmentType.AutoSize = True
        lblAssessmentType.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblAssessmentType.Location = New Point(53, 48)
        lblAssessmentType.Name = "lblAssessmentType"
        lblAssessmentType.Size = New Size(142, 15)
        lblAssessmentType.TabIndex = 0
        lblAssessmentType.Text = "Select Assessment Type:"
        ' 
        ' cmbAssessment
        ' 
        cmbAssessment.FormattingEnabled = True
        cmbAssessment.Location = New Point(56, 69)
        cmbAssessment.Name = "cmbAssessment"
        cmbAssessment.Size = New Size(190, 23)
        cmbAssessment.TabIndex = 1
        ' 
        ' cmbStudent
        ' 
        cmbStudent.FormattingEnabled = True
        cmbStudent.Location = New Point(56, 131)
        cmbStudent.Name = "cmbStudent"
        cmbStudent.Size = New Size(190, 23)
        cmbStudent.TabIndex = 7
        ' 
        ' lblStudentCourse
        ' 
        lblStudentCourse.AutoSize = True
        lblStudentCourse.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblStudentCourse.Location = New Point(53, 110)
        lblStudentCourse.Name = "lblStudentCourse"
        lblStudentCourse.Size = New Size(134, 15)
        lblStudentCourse.TabIndex = 6
        lblStudentCourse.Text = "Select Student Course:"
        ' 
        ' cmbCourse
        ' 
        cmbCourse.FormattingEnabled = True
        cmbCourse.Location = New Point(56, 191)
        cmbCourse.Name = "cmbCourse"
        cmbCourse.Size = New Size(190, 23)
        cmbCourse.TabIndex = 9
        ' 
        ' lblCourseCode
        ' 
        lblCourseCode.AutoSize = True
        lblCourseCode.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblCourseCode.Location = New Point(55, 170)
        lblCourseCode.Name = "lblCourseCode"
        lblCourseCode.Size = New Size(117, 15)
        lblCourseCode.TabIndex = 8
        lblCourseCode.Text = "Select Course Code:"
        ' 
        ' btnBack
        ' 
        btnBack.BackColor = Color.Transparent
        btnBack.FlatAppearance.BorderColor = Color.DarkGray
        btnBack.FlatAppearance.MouseOverBackColor = Color.LightGray
        btnBack.FlatStyle = FlatStyle.Flat
        btnBack.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnBack.Location = New Point(150, 233)
        btnBack.Name = "btnBack"
        btnBack.Size = New Size(75, 27)
        btnBack.TabIndex = 14
        btnBack.Text = "Back"
        btnBack.UseVisualStyleBackColor = False
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.Transparent
        Button1.FlatAppearance.BorderColor = Color.DarkGray
        Button1.FlatAppearance.MouseOverBackColor = Color.LightGray
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button1.Location = New Point(322, 233)
        Button1.Name = "Button1"
        Button1.Size = New Size(75, 27)
        Button1.TabIndex = 15
        Button1.Text = "SAVE"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' ASSESSMENT
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(555, 280)
        Controls.Add(Button1)
        Controls.Add(btnBack)
        Controls.Add(cmbCourse)
        Controls.Add(lblCourseCode)
        Controls.Add(cmbStudent)
        Controls.Add(lblStudentCourse)
        Controls.Add(cmbAssessment)
        Controls.Add(lblAssessmentType)
        FormBorderStyle = FormBorderStyle.None
        Name = "ASSESSMENT"
        StartPosition = FormStartPosition.CenterScreen
        Text = "ASSESSMENT"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblAssessmentType As Label
    Friend WithEvents cmbAssessment As ComboBox
    Friend WithEvents cmbStudent As ComboBox
    Friend WithEvents lblStudentCourse As Label
    Friend WithEvents cmbCourse As ComboBox
    Friend WithEvents lblCourseCode As Label
    Friend WithEvents btnBack As Button
    Friend WithEvents Button1 As Button
End Class
