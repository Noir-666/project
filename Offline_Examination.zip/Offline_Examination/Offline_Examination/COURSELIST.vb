﻿Public Class CourseList
    Private Sub txtSearch_MouseHover(sender As Object, e As EventArgs) Handles txtSearch.MouseHover
        txtSearch.BackColor = Color.Gainsboro


    End Sub

    Private Sub txtSearch_MouseLeave(sender As Object, e As EventArgs) Handles txtSearch.MouseLeave
        txtSearch.BackColor = Color.White
    End Sub
End Class