﻿Public Class Course
    Private Sub txtAddcourse_MouseHover(sender As Object, e As EventArgs) Handles txtAddcourse.MouseHover
        txtAddcourse.BackColor = Color.Gainsboro
    End Sub

    Private Sub txtAddcourse_MouseLeave(sender As Object, e As EventArgs) Handles txtAddcourse.MouseLeave
        txtAddcourse.BackColor = Color.White
    End Sub

    Private Sub txtCoursecode_MouseHover(sender As Object, e As EventArgs) Handles txtCoursecode.MouseHover
        txtCoursecode.BackColor = Color.Gainsboro
    End Sub

    Private Sub txtCoursecode_MouseLeave(sender As Object, e As EventArgs) Handles txtCoursecode.MouseLeave
        txtCoursecode.BackColor = Color.White
    End Sub
End Class