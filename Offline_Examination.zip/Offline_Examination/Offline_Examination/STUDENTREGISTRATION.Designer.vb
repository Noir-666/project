﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class STUDENTREGISTRATION
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        Label1 = New Label()
        GroupBox1 = New GroupBox()
        PictureBox1 = New PictureBox()
        Button3 = New Button()
        Button2 = New Button()
        Button1 = New Button()
        txtContact = New TextBox()
        txtEmail = New TextBox()
        CheckedListBox2 = New CheckedListBox()
        CheckedListBox1 = New CheckedListBox()
        DateTimePicker1 = New DateTimePicker()
        txtMiddlename = New TextBox()
        txtLastname = New TextBox()
        txtFirstname = New TextBox()
        lblContactNumber = New Label()
        lblEmailAddress = New Label()
        lblGender = New Label()
        lblDateofBirth = New Label()
        lblMiddleName = New Label()
        lblLastName = New Label()
        lblFirstName = New Label()
        Panel1.SuspendLayout()
        GroupBox1.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Maroon
        Panel1.Controls.Add(Label1)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(811, 68)
        Panel1.TabIndex = 2
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.White
        Label1.Location = New Point(16, 17)
        Label1.Name = "Label1"
        Label1.Size = New Size(248, 32)
        Label1.TabIndex = 0
        Label1.Text = "Student Registration"
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(PictureBox1)
        GroupBox1.Controls.Add(Button3)
        GroupBox1.Controls.Add(Button2)
        GroupBox1.Controls.Add(Button1)
        GroupBox1.Controls.Add(txtContact)
        GroupBox1.Controls.Add(txtEmail)
        GroupBox1.Controls.Add(CheckedListBox2)
        GroupBox1.Controls.Add(CheckedListBox1)
        GroupBox1.Controls.Add(DateTimePicker1)
        GroupBox1.Controls.Add(txtMiddlename)
        GroupBox1.Controls.Add(txtLastname)
        GroupBox1.Controls.Add(txtFirstname)
        GroupBox1.Controls.Add(lblContactNumber)
        GroupBox1.Controls.Add(lblEmailAddress)
        GroupBox1.Controls.Add(lblGender)
        GroupBox1.Controls.Add(lblDateofBirth)
        GroupBox1.Controls.Add(lblMiddleName)
        GroupBox1.Controls.Add(lblLastName)
        GroupBox1.Controls.Add(lblFirstName)
        GroupBox1.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        GroupBox1.Location = New Point(12, 80)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(787, 325)
        GroupBox1.TabIndex = 3
        GroupBox1.TabStop = False
        GroupBox1.Text = "Registration Form"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.Image = My.Resources.Resources.Maroon_logo_removebg_preview
        PictureBox1.Location = New Point(494, 47)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(257, 234)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 15
        PictureBox1.TabStop = False
        ' 
        ' Button3
        ' 
        Button3.FlatAppearance.BorderColor = Color.DimGray
        Button3.FlatAppearance.MouseDownBackColor = Color.LightGray
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button3.Location = New Point(354, 293)
        Button3.Name = "Button3"
        Button3.Size = New Size(75, 23)
        Button3.TabIndex = 18
        Button3.Text = "Exit"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.FlatAppearance.BorderColor = Color.DimGray
        Button2.FlatAppearance.MouseDownBackColor = Color.LightGray
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button2.Location = New Point(240, 293)
        Button2.Name = "Button2"
        Button2.Size = New Size(75, 23)
        Button2.TabIndex = 17
        Button2.Text = "Clear"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.FlatAppearance.BorderColor = Color.DimGray
        Button1.FlatAppearance.MouseDownBackColor = Color.LightGray
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button1.Location = New Point(132, 293)
        Button1.Name = "Button1"
        Button1.Size = New Size(75, 23)
        Button1.TabIndex = 16
        Button1.Text = "Register"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' txtContact
        ' 
        txtContact.Location = New Point(132, 261)
        txtContact.Multiline = True
        txtContact.Name = "txtContact"
        txtContact.Size = New Size(245, 23)
        txtContact.TabIndex = 14
        ' 
        ' txtEmail
        ' 
        txtEmail.Location = New Point(132, 228)
        txtEmail.Multiline = True
        txtEmail.Name = "txtEmail"
        txtEmail.Size = New Size(245, 23)
        txtEmail.TabIndex = 13
        ' 
        ' CheckedListBox2
        ' 
        CheckedListBox2.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        CheckedListBox2.FormattingEnabled = True
        CheckedListBox2.Items.AddRange(New Object() {"Female"})
        CheckedListBox2.Location = New Point(196, 194)
        CheckedListBox2.Name = "CheckedListBox2"
        CheckedListBox2.Size = New Size(68, 22)
        CheckedListBox2.TabIndex = 12
        ' 
        ' CheckedListBox1
        ' 
        CheckedListBox1.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        CheckedListBox1.FormattingEnabled = True
        CheckedListBox1.Items.AddRange(New Object() {"Male"})
        CheckedListBox1.Location = New Point(132, 194)
        CheckedListBox1.Name = "CheckedListBox1"
        CheckedListBox1.Size = New Size(58, 22)
        CheckedListBox1.TabIndex = 11
        ' 
        ' DateTimePicker1
        ' 
        DateTimePicker1.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        DateTimePicker1.Location = New Point(132, 158)
        DateTimePicker1.Name = "DateTimePicker1"
        DateTimePicker1.Size = New Size(245, 23)
        DateTimePicker1.TabIndex = 10
        ' 
        ' txtMiddlename
        ' 
        txtMiddlename.Location = New Point(132, 79)
        txtMiddlename.Multiline = True
        txtMiddlename.Name = "txtMiddlename"
        txtMiddlename.Size = New Size(245, 24)
        txtMiddlename.TabIndex = 9
        ' 
        ' txtLastname
        ' 
        txtLastname.Location = New Point(132, 111)
        txtLastname.Multiline = True
        txtLastname.Name = "txtLastname"
        txtLastname.Size = New Size(245, 23)
        txtLastname.TabIndex = 8
        ' 
        ' txtFirstname
        ' 
        txtFirstname.Location = New Point(132, 47)
        txtFirstname.Multiline = True
        txtFirstname.Name = "txtFirstname"
        txtFirstname.Size = New Size(245, 23)
        txtFirstname.TabIndex = 7
        ' 
        ' lblContactNumber
        ' 
        lblContactNumber.AutoSize = True
        lblContactNumber.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblContactNumber.Location = New Point(28, 266)
        lblContactNumber.Name = "lblContactNumber"
        lblContactNumber.Size = New Size(102, 15)
        lblContactNumber.TabIndex = 6
        lblContactNumber.Text = "Contact Number:"
        ' 
        ' lblEmailAddress
        ' 
        lblEmailAddress.AutoSize = True
        lblEmailAddress.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblEmailAddress.Location = New Point(44, 233)
        lblEmailAddress.Name = "lblEmailAddress"
        lblEmailAddress.Size = New Size(86, 15)
        lblEmailAddress.TabIndex = 5
        lblEmailAddress.Text = "Email Address:"
        ' 
        ' lblGender
        ' 
        lblGender.AutoSize = True
        lblGender.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblGender.Location = New Point(78, 199)
        lblGender.Name = "lblGender"
        lblGender.Size = New Size(52, 15)
        lblGender.TabIndex = 4
        lblGender.Text = "Gender:"
        ' 
        ' lblDateofBirth
        ' 
        lblDateofBirth.AutoSize = True
        lblDateofBirth.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblDateofBirth.Location = New Point(47, 162)
        lblDateofBirth.Name = "lblDateofBirth"
        lblDateofBirth.Size = New Size(83, 15)
        lblDateofBirth.TabIndex = 3
        lblDateofBirth.Text = "Date of Birth:"
        ' 
        ' lblMiddleName
        ' 
        lblMiddleName.AutoSize = True
        lblMiddleName.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblMiddleName.Location = New Point(46, 84)
        lblMiddleName.Name = "lblMiddleName"
        lblMiddleName.Size = New Size(84, 15)
        lblMiddleName.TabIndex = 2
        lblMiddleName.Text = "Middle Name:"
        ' 
        ' lblLastName
        ' 
        lblLastName.AutoSize = True
        lblLastName.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblLastName.Location = New Point(61, 116)
        lblLastName.Name = "lblLastName"
        lblLastName.Size = New Size(68, 15)
        lblLastName.TabIndex = 1
        lblLastName.Text = "Last Name:"
        ' 
        ' lblFirstName
        ' 
        lblFirstName.AutoSize = True
        lblFirstName.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblFirstName.Location = New Point(60, 51)
        lblFirstName.Name = "lblFirstName"
        lblFirstName.Size = New Size(70, 15)
        lblFirstName.TabIndex = 0
        lblFirstName.Text = "First Name:"
        ' 
        ' STUDENTREGISTRATION
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(811, 419)
        Controls.Add(GroupBox1)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        Name = "STUDENTREGISTRATION"
        StartPosition = FormStartPosition.CenterScreen
        Text = "STUDENTREGISTRATION"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lblContactNumber As Label
    Friend WithEvents lblEmailAddress As Label
    Friend WithEvents lblGender As Label
    Friend WithEvents lblDateofBirth As Label
    Friend WithEvents lblMiddleName As Label
    Friend WithEvents lblLastName As Label
    Friend WithEvents lblFirstName As Label
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents CheckedListBox2 As CheckedListBox
    Friend WithEvents CheckedListBox1 As CheckedListBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents txtMiddlename As TextBox
    Friend WithEvents txtLastname As TextBox
    Friend WithEvents txtFirstname As TextBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents txtContact As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
End Class
