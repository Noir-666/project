﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ADMIN
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        PictureBox1 = New PictureBox()
        Panel1 = New Panel()
        btnStatistic = New Button()
        btnRegister = New Button()
        btnQuestions = New Button()
        btnExam = New Button()
        btnAssign = New Button()
        btnDashboard = New Button()
        btnCourse = New Button()
        Button2 = New Button()
        btnSection = New Button()
        btnExit = New Button()
        Label1 = New Label()
        Button9 = New Button()
        Panel2 = New Panel()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.USER
        PictureBox1.Location = New Point(26, 12)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(188, 113)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Maroon
        Panel1.Controls.Add(btnStatistic)
        Panel1.Controls.Add(btnRegister)
        Panel1.Controls.Add(btnQuestions)
        Panel1.Controls.Add(btnExam)
        Panel1.Controls.Add(btnAssign)
        Panel1.Controls.Add(btnDashboard)
        Panel1.Controls.Add(btnCourse)
        Panel1.Controls.Add(Button2)
        Panel1.Controls.Add(btnSection)
        Panel1.Controls.Add(btnExit)
        Panel1.Controls.Add(Label1)
        Panel1.Controls.Add(Button9)
        Panel1.Controls.Add(PictureBox1)
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(246, 719)
        Panel1.TabIndex = 0
        ' 
        ' btnStatistic
        ' 
        btnStatistic.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        btnStatistic.BackColor = Color.Transparent
        btnStatistic.BackgroundImageLayout = ImageLayout.None
        btnStatistic.FlatAppearance.BorderSize = 0
        btnStatistic.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(179), CByte(57), CByte(57))
        btnStatistic.FlatStyle = FlatStyle.Flat
        btnStatistic.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        btnStatistic.ForeColor = Color.White
        btnStatistic.Image = My.Resources.Resources.icons8_folder_30
        btnStatistic.ImageAlign = ContentAlignment.MiddleLeft
        btnStatistic.Location = New Point(-1, 530)
        btnStatistic.Name = "btnStatistic"
        btnStatistic.Size = New Size(246, 39)
        btnStatistic.TabIndex = 17
        btnStatistic.Text = "Statistics"
        btnStatistic.UseVisualStyleBackColor = False
        ' 
        ' btnRegister
        ' 
        btnRegister.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        btnRegister.BackColor = Color.Transparent
        btnRegister.BackgroundImageLayout = ImageLayout.None
        btnRegister.FlatAppearance.BorderSize = 0
        btnRegister.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(179), CByte(57), CByte(57))
        btnRegister.FlatStyle = FlatStyle.Flat
        btnRegister.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        btnRegister.ForeColor = Color.White
        btnRegister.Image = My.Resources.Resources.icons8_student_registration_24
        btnRegister.ImageAlign = ContentAlignment.MiddleLeft
        btnRegister.Location = New Point(-2, 480)
        btnRegister.Name = "btnRegister"
        btnRegister.Size = New Size(246, 39)
        btnRegister.TabIndex = 18
        btnRegister.Text = "Register Students"
        btnRegister.UseVisualStyleBackColor = False
        ' 
        ' btnQuestions
        ' 
        btnQuestions.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        btnQuestions.BackColor = Color.Transparent
        btnQuestions.BackgroundImageLayout = ImageLayout.None
        btnQuestions.FlatAppearance.BorderSize = 0
        btnQuestions.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(179), CByte(57), CByte(57))
        btnQuestions.FlatStyle = FlatStyle.Flat
        btnQuestions.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        btnQuestions.ForeColor = Color.White
        btnQuestions.Image = My.Resources.Resources.icons8_questions_24
        btnQuestions.ImageAlign = ContentAlignment.MiddleLeft
        btnQuestions.Location = New Point(-1, 380)
        btnQuestions.Name = "btnQuestions"
        btnQuestions.Size = New Size(246, 39)
        btnQuestions.TabIndex = 16
        btnQuestions.Text = "Questions"
        btnQuestions.UseVisualStyleBackColor = False
        ' 
        ' btnExam
        ' 
        btnExam.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        btnExam.BackColor = Color.Transparent
        btnExam.BackgroundImageLayout = ImageLayout.None
        btnExam.FlatAppearance.BorderSize = 0
        btnExam.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(179), CByte(57), CByte(57))
        btnExam.FlatStyle = FlatStyle.Flat
        btnExam.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        btnExam.ForeColor = Color.White
        btnExam.Image = My.Resources.Resources.icons8_exam_24
        btnExam.ImageAlign = ContentAlignment.MiddleLeft
        btnExam.Location = New Point(-1, 330)
        btnExam.Name = "btnExam"
        btnExam.Size = New Size(246, 39)
        btnExam.TabIndex = 15
        btnExam.Text = "Exam"
        btnExam.UseVisualStyleBackColor = False
        ' 
        ' btnAssign
        ' 
        btnAssign.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        btnAssign.BackColor = Color.Transparent
        btnAssign.BackgroundImageLayout = ImageLayout.None
        btnAssign.FlatAppearance.BorderSize = 0
        btnAssign.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(179), CByte(57), CByte(57))
        btnAssign.FlatStyle = FlatStyle.Flat
        btnAssign.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        btnAssign.ForeColor = Color.White
        btnAssign.Image = My.Resources.Resources.icons8_student_center_24
        btnAssign.ImageAlign = ContentAlignment.MiddleLeft
        btnAssign.Location = New Point(-2, 430)
        btnAssign.Name = "btnAssign"
        btnAssign.Size = New Size(246, 39)
        btnAssign.TabIndex = 19
        btnAssign.Text = "Assign Students"
        btnAssign.UseVisualStyleBackColor = False
        ' 
        ' btnDashboard
        ' 
        btnDashboard.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        btnDashboard.BackColor = Color.Transparent
        btnDashboard.BackgroundImageLayout = ImageLayout.None
        btnDashboard.FlatAppearance.BorderSize = 0
        btnDashboard.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(179), CByte(57), CByte(57))
        btnDashboard.FlatStyle = FlatStyle.Flat
        btnDashboard.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        btnDashboard.ForeColor = Color.White
        btnDashboard.Image = My.Resources.Resources.icons8_dashboard_24
        btnDashboard.ImageAlign = ContentAlignment.MiddleLeft
        btnDashboard.Location = New Point(-3, 185)
        btnDashboard.Name = "btnDashboard"
        btnDashboard.Size = New Size(246, 39)
        btnDashboard.TabIndex = 15
        btnDashboard.Text = "DashBoard"
        btnDashboard.UseVisualStyleBackColor = False
        ' 
        ' btnCourse
        ' 
        btnCourse.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        btnCourse.BackColor = Color.Transparent
        btnCourse.BackgroundImageLayout = ImageLayout.None
        btnCourse.FlatAppearance.BorderSize = 0
        btnCourse.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(179), CByte(57), CByte(57))
        btnCourse.FlatStyle = FlatStyle.Flat
        btnCourse.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        btnCourse.ForeColor = Color.White
        btnCourse.Image = My.Resources.Resources.icons8_folder_30
        btnCourse.ImageAlign = ContentAlignment.MiddleLeft
        btnCourse.Location = New Point(-2, 233)
        btnCourse.Name = "btnCourse"
        btnCourse.Size = New Size(246, 39)
        btnCourse.TabIndex = 14
        btnCourse.Text = "Course"
        btnCourse.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        Button2.BackColor = Color.Black
        Button2.BackgroundImageLayout = ImageLayout.None
        Button2.FlatAppearance.BorderSize = 0
        Button2.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(179), CByte(57), CByte(57))
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button2.ForeColor = Color.White
        Button2.Location = New Point(-3, 185)
        Button2.Name = "Button2"
        Button2.Size = New Size(246, 39)
        Button2.TabIndex = 15
        Button2.Text = "DashBoard"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' btnSection
        ' 
        btnSection.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        btnSection.BackColor = Color.Transparent
        btnSection.BackgroundImageLayout = ImageLayout.None
        btnSection.FlatAppearance.BorderSize = 0
        btnSection.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(179), CByte(57), CByte(57))
        btnSection.FlatStyle = FlatStyle.Flat
        btnSection.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        btnSection.ForeColor = Color.White
        btnSection.Image = My.Resources.Resources.icons8_folder_30
        btnSection.ImageAlign = ContentAlignment.MiddleLeft
        btnSection.Location = New Point(-2, 281)
        btnSection.Name = "btnSection"
        btnSection.Size = New Size(246, 39)
        btnSection.TabIndex = 14
        btnSection.Text = "Section"
        btnSection.UseVisualStyleBackColor = False
        ' 
        ' btnExit
        ' 
        btnExit.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        btnExit.BackColor = Color.Transparent
        btnExit.BackgroundImageLayout = ImageLayout.None
        btnExit.FlatAppearance.BorderSize = 0
        btnExit.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(179), CByte(57), CByte(57))
        btnExit.FlatStyle = FlatStyle.Flat
        btnExit.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        btnExit.ForeColor = Color.White
        btnExit.Image = My.Resources.Resources.icons8_logout_24
        btnExit.ImageAlign = ContentAlignment.MiddleLeft
        btnExit.Location = New Point(-1, 659)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(246, 39)
        btnExit.TabIndex = 12
        btnExit.Text = "Logout"
        btnExit.UseVisualStyleBackColor = False
        ' 
        ' Label1
        ' 
        Label1.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        Label1.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.Cyan
        Label1.Location = New Point(0, 131)
        Label1.Name = "Label1"
        Label1.Size = New Size(247, 23)
        Label1.TabIndex = 11
        Label1.Text = "ADMINISTRATOR"
        Label1.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Button9
        ' 
        Button9.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        Button9.BackColor = Color.Transparent
        Button9.BackgroundImageLayout = ImageLayout.None
        Button9.FlatAppearance.BorderSize = 0
        Button9.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(179), CByte(57), CByte(57))
        Button9.FlatStyle = FlatStyle.Flat
        Button9.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Button9.ForeColor = Color.White
        Button9.Image = My.Resources.Resources.icons8_folder_30
        Button9.ImageAlign = ContentAlignment.MiddleLeft
        Button9.Location = New Point(-1, 607)
        Button9.Name = "Button9"
        Button9.Size = New Size(246, 39)
        Button9.TabIndex = 9
        Button9.Text = "DashBoard"
        Button9.UseVisualStyleBackColor = False
        ' 
        ' Panel2
        ' 
        Panel2.Dock = DockStyle.Right
        Panel2.Location = New Point(245, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(882, 719)
        Panel2.TabIndex = 1
        ' 
        ' ADMIN
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1127, 719)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        Name = "ADMIN"
        StartPosition = FormStartPosition.CenterScreen
        Text = "ADMIN"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        Panel1.ResumeLayout(False)
        ResumeLayout(False)
    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button9 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents btnStatistic As Button
    Friend WithEvents btnRegister As Button
    Friend WithEvents btnQuestions As Button
    Friend WithEvents btnExam As Button
    Friend WithEvents btnAssign As Button
    Friend WithEvents btnDashboard As Button
    Friend WithEvents btnCourse As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents btnSection As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents Panel2 As Panel
End Class
