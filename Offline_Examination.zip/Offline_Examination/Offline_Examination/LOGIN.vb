﻿Imports System.Runtime.CompilerServices

Public Class LOGIN
    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint
        Panel1.BackColor = Color.FromArgb(75, 0, 0, 0)
    End Sub

    Private Sub txtUser_MouseHover(sender As Object, e As EventArgs) Handles txtUser.MouseHover
        txtUser.BackColor = Color.LightGray
    End Sub

    Private Sub txtUser_MouseLeave(sender As Object, e As EventArgs) Handles txtUser.MouseLeave
        txtUser.BackColor = Color.White
    End Sub

    Private Sub txtPass_MouseHover(sender As Object, e As EventArgs) Handles txtPass.MouseHover
        txtPass.BackColor = Color.LightGray
    End Sub

    Private Sub txtPass_MouseLeave(sender As Object, e As EventArgs) Handles txtPass.MouseLeave
        txtPass.BackColor = Color.White
    End Sub

    Private Sub LOGIN_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
