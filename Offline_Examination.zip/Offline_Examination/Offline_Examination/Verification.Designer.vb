﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Verification
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        lblUsername = New Label()
        lblPassword = New Label()
        Label3 = New Label()
        Panel1 = New Panel()
        txtUsername = New TextBox()
        txtPassword = New TextBox()
        btnVerify = New Button()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' lblUsername
        ' 
        lblUsername.AutoSize = True
        lblUsername.BackColor = Color.Transparent
        lblUsername.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblUsername.ForeColor = Color.Black
        lblUsername.Location = New Point(52, 76)
        lblUsername.Name = "lblUsername"
        lblUsername.Size = New Size(73, 17)
        lblUsername.TabIndex = 0
        lblUsername.Text = "Username:"
        ' 
        ' lblPassword
        ' 
        lblPassword.AutoSize = True
        lblPassword.BackColor = Color.Transparent
        lblPassword.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblPassword.ForeColor = Color.Black
        lblPassword.Location = New Point(55, 126)
        lblPassword.Name = "lblPassword"
        lblPassword.Size = New Size(70, 17)
        lblPassword.TabIndex = 1
        lblPassword.Text = "Password:"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = Color.White
        Label3.Location = New Point(36, 6)
        Label3.Name = "Label3"
        Label3.Size = New Size(386, 30)
        Label3.TabIndex = 2
        Label3.Text = "Re-Type your Username and Password"
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Maroon
        Panel1.BackgroundImageLayout = ImageLayout.None
        Panel1.Controls.Add(Label3)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(455, 49)
        Panel1.TabIndex = 3
        ' 
        ' txtUsername
        ' 
        txtUsername.Location = New Point(129, 74)
        txtUsername.Name = "txtUsername"
        txtUsername.Size = New Size(266, 23)
        txtUsername.TabIndex = 3
        ' 
        ' txtPassword
        ' 
        txtPassword.Location = New Point(129, 123)
        txtPassword.Name = "txtPassword"
        txtPassword.Size = New Size(266, 23)
        txtPassword.TabIndex = 4
        ' 
        ' btnVerify
        ' 
        btnVerify.FlatAppearance.BorderColor = Color.DimGray
        btnVerify.FlatAppearance.MouseOverBackColor = Color.LightGray
        btnVerify.FlatStyle = FlatStyle.Flat
        btnVerify.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnVerify.Location = New Point(182, 161)
        btnVerify.Name = "btnVerify"
        btnVerify.Size = New Size(78, 25)
        btnVerify.TabIndex = 5
        btnVerify.Text = "VERIFY"
        btnVerify.UseVisualStyleBackColor = True
        ' 
        ' Verification
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(455, 198)
        Controls.Add(Panel1)
        Controls.Add(btnVerify)
        Controls.Add(txtUsername)
        Controls.Add(txtPassword)
        Controls.Add(lblUsername)
        Controls.Add(lblPassword)
        FormBorderStyle = FormBorderStyle.None
        Name = "Verification"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Verification"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblUsername As Label
    Friend WithEvents lblPassword As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnVerify As Button
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents txtUsername As TextBox
End Class
