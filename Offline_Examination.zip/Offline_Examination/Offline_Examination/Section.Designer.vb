﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Section
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        Label1 = New Label()
        lblSection = New Label()
        lblCourseCode = New Label()
        txtSection = New TextBox()
        cmbCourseCode = New ComboBox()
        btnBack = New Button()
        btnAdd = New Button()
        btnUpdate = New Button()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Maroon
        Panel1.Controls.Add(Label1)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(463, 52)
        Panel1.TabIndex = 0
        ' 
        ' Label1
        ' 
        Label1.Dock = DockStyle.Left
        Label1.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.White
        Label1.Location = New Point(0, 0)
        Label1.Name = "Label1"
        Label1.Size = New Size(463, 52)
        Label1.TabIndex = 0
        Label1.Text = "Add Section"
        Label1.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' lblSection
        ' 
        lblSection.AutoSize = True
        lblSection.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblSection.Location = New Point(57, 77)
        lblSection.Name = "lblSection"
        lblSection.Size = New Size(57, 17)
        lblSection.TabIndex = 1
        lblSection.Text = "Section:"
        ' 
        ' lblCourseCode
        ' 
        lblCourseCode.AutoSize = True
        lblCourseCode.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblCourseCode.Location = New Point(25, 123)
        lblCourseCode.Name = "lblCourseCode"
        lblCourseCode.Size = New Size(89, 17)
        lblCourseCode.TabIndex = 2
        lblCourseCode.Text = "Course Code:"
        ' 
        ' txtSection
        ' 
        txtSection.BorderStyle = BorderStyle.FixedSingle
        txtSection.Location = New Point(117, 74)
        txtSection.Multiline = True
        txtSection.Name = "txtSection"
        txtSection.Size = New Size(298, 23)
        txtSection.TabIndex = 3
        ' 
        ' cmbCourseCode
        ' 
        cmbCourseCode.FormattingEnabled = True
        cmbCourseCode.Location = New Point(117, 120)
        cmbCourseCode.Name = "cmbCourseCode"
        cmbCourseCode.Size = New Size(298, 23)
        cmbCourseCode.TabIndex = 4
        ' 
        ' btnBack
        ' 
        btnBack.BackColor = Color.Transparent
        btnBack.FlatAppearance.BorderColor = Color.DarkGray
        btnBack.FlatAppearance.MouseOverBackColor = Color.LightGray
        btnBack.FlatStyle = FlatStyle.Flat
        btnBack.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnBack.Location = New Point(117, 167)
        btnBack.Name = "btnBack"
        btnBack.Size = New Size(75, 27)
        btnBack.TabIndex = 5
        btnBack.Text = "Back"
        btnBack.UseVisualStyleBackColor = False
        ' 
        ' btnAdd
        ' 
        btnAdd.BackColor = Color.Transparent
        btnAdd.FlatAppearance.BorderColor = Color.DarkGray
        btnAdd.FlatAppearance.MouseOverBackColor = Color.LightGray
        btnAdd.FlatStyle = FlatStyle.Flat
        btnAdd.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnAdd.Location = New Point(231, 167)
        btnAdd.Name = "btnAdd"
        btnAdd.Size = New Size(75, 27)
        btnAdd.TabIndex = 6
        btnAdd.Text = "Add"
        btnAdd.UseVisualStyleBackColor = False
        ' 
        ' btnUpdate
        ' 
        btnUpdate.BackColor = Color.Transparent
        btnUpdate.FlatAppearance.BorderColor = Color.DarkGray
        btnUpdate.FlatAppearance.MouseOverBackColor = Color.LightGray
        btnUpdate.FlatStyle = FlatStyle.Flat
        btnUpdate.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnUpdate.Location = New Point(340, 167)
        btnUpdate.Name = "btnUpdate"
        btnUpdate.Size = New Size(75, 27)
        btnUpdate.TabIndex = 7
        btnUpdate.Text = "Update"
        btnUpdate.UseVisualStyleBackColor = False
        ' 
        ' Section
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(463, 217)
        Controls.Add(btnUpdate)
        Controls.Add(btnAdd)
        Controls.Add(btnBack)
        Controls.Add(cmbCourseCode)
        Controls.Add(txtSection)
        Controls.Add(lblCourseCode)
        Controls.Add(lblSection)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        Name = "Section"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Section"
        Panel1.ResumeLayout(False)
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents lblSection As Label
    Friend WithEvents lblCourseCode As Label
    Friend WithEvents txtSection As TextBox
    Friend WithEvents cmbCourseCode As ComboBox
    Friend WithEvents btnBack As Button
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnUpdate As Button
End Class
