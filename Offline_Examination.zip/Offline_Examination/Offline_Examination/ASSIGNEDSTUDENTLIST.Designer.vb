﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ASSIGNEDSTUDENTLIST
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        btnSearch = New Button()
        txtSearch = New TextBox()
        btnAdd = New Button()
        DataGridView1 = New DataGridView()
        ColNom = New DataGridViewTextBoxColumn()
        colStudentNumber = New DataGridViewTextBoxColumn()
        colStudentName = New DataGridViewTextBoxColumn()
        colCourseCode = New DataGridViewTextBoxColumn()
        colAssessType = New DataGridViewTextBoxColumn()
        colEdit = New DataGridViewImageColumn()
        colDelete = New DataGridViewImageColumn()
        Panel1.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Maroon
        Panel1.Controls.Add(btnSearch)
        Panel1.Controls.Add(txtSearch)
        Panel1.Controls.Add(btnAdd)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(744, 59)
        Panel1.TabIndex = 2
        ' 
        ' btnSearch
        ' 
        btnSearch.BackColor = Color.WhiteSmoke
        btnSearch.FlatAppearance.BorderSize = 0
        btnSearch.FlatAppearance.MouseDownBackColor = Color.LightGray
        btnSearch.FlatStyle = FlatStyle.Flat
        btnSearch.Image = My.Resources.Resources.blackSearch
        btnSearch.Location = New Point(25, 17)
        btnSearch.Name = "btnSearch"
        btnSearch.Size = New Size(42, 26)
        btnSearch.TabIndex = 2
        btnSearch.UseVisualStyleBackColor = False
        ' 
        ' txtSearch
        ' 
        txtSearch.BackColor = Color.WhiteSmoke
        txtSearch.BorderStyle = BorderStyle.None
        txtSearch.Font = New Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtSearch.ForeColor = Color.Black
        txtSearch.Location = New Point(66, 17)
        txtSearch.Multiline = True
        txtSearch.Name = "txtSearch"
        txtSearch.Size = New Size(236, 26)
        txtSearch.TabIndex = 1
        ' 
        ' btnAdd
        ' 
        btnAdd.FlatAppearance.BorderSize = 0
        btnAdd.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(179), CByte(57), CByte(57))
        btnAdd.FlatStyle = FlatStyle.Flat
        btnAdd.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnAdd.ForeColor = Color.White
        btnAdd.Image = My.Resources.Resources.icons8_add_16
        btnAdd.ImageAlign = ContentAlignment.MiddleRight
        btnAdd.Location = New Point(659, 15)
        btnAdd.Name = "btnAdd"
        btnAdd.Size = New Size(67, 30)
        btnAdd.TabIndex = 0
        btnAdd.Text = "Add"
        btnAdd.UseVisualStyleBackColor = True
        ' 
        ' DataGridView1
        ' 
        DataGridView1.AllowUserToAddRows = False
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Columns.AddRange(New DataGridViewColumn() {ColNom, colStudentNumber, colStudentName, colCourseCode, colAssessType, colEdit, colDelete})
        DataGridView1.Location = New Point(13, 72)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.ReadOnly = True
        DataGridView1.Size = New Size(718, 359)
        DataGridView1.TabIndex = 3
        ' 
        ' ColNom
        ' 
        ColNom.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        ColNom.HeaderText = "#"
        ColNom.MinimumWidth = 6
        ColNom.Name = "ColNom"
        ColNom.ReadOnly = True
        ColNom.Width = 39
        ' 
        ' colStudentNumber
        ' 
        colStudentNumber.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        colStudentNumber.HeaderText = "Student Number"
        colStudentNumber.MinimumWidth = 6
        colStudentNumber.Name = "colStudentNumber"
        colStudentNumber.ReadOnly = True
        colStudentNumber.Width = 110
        ' 
        ' colStudentName
        ' 
        colStudentName.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
        colStudentName.HeaderText = "Student Name"
        colStudentName.MinimumWidth = 6
        colStudentName.Name = "colStudentName"
        colStudentName.ReadOnly = True
        ' 
        ' colCourseCode
        ' 
        colCourseCode.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        colCourseCode.HeaderText = "Course Code"
        colCourseCode.MinimumWidth = 6
        colCourseCode.Name = "colCourseCode"
        colCourseCode.ReadOnly = True
        colCourseCode.Width = 92
        ' 
        ' colAssessType
        ' 
        colAssessType.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        colAssessType.HeaderText = "Assigned Assess. Type"
        colAssessType.MinimumWidth = 6
        colAssessType.Name = "colAssessType"
        colAssessType.ReadOnly = True
        colAssessType.Width = 113
        ' 
        ' colEdit
        ' 
        colEdit.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        colEdit.HeaderText = "Edit"
        colEdit.Image = My.Resources.Resources.icons8_edit_24
        colEdit.MinimumWidth = 6
        colEdit.Name = "colEdit"
        colEdit.ReadOnly = True
        colEdit.Width = 33
        ' 
        ' colDelete
        ' 
        colDelete.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        colDelete.HeaderText = "Delete"
        colDelete.Image = My.Resources.Resources.icons8_x_coordinate_24
        colDelete.MinimumWidth = 6
        colDelete.Name = "colDelete"
        colDelete.ReadOnly = True
        colDelete.Width = 46
        ' 
        ' ASSIGNEDSTUDENTLIST
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(744, 446)
        Controls.Add(DataGridView1)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        Name = "ASSIGNEDSTUDENTLIST"
        StartPosition = FormStartPosition.CenterScreen
        Text = "ASSIGNEDSTUDENTLIST"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnSearch As Button
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents ColNom As DataGridViewTextBoxColumn
    Friend WithEvents colStudentNumber As DataGridViewTextBoxColumn
    Friend WithEvents colStudentName As DataGridViewTextBoxColumn
    Friend WithEvents colCourseCode As DataGridViewTextBoxColumn
    Friend WithEvents colAssessType As DataGridViewTextBoxColumn
    Friend WithEvents colEdit As DataGridViewImageColumn
    Friend WithEvents colDelete As DataGridViewImageColumn
End Class
