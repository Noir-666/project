﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class STUDENT
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        Panel2 = New Panel()
        PictureBox1 = New PictureBox()
        Label1 = New Label()
        btnDashboard = New Button()
        Button1 = New Button()
        Button2 = New Button()
        Button3 = New Button()
        btnExit = New Button()
        Panel1.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Maroon
        Panel1.Controls.Add(btnExit)
        Panel1.Controls.Add(Button3)
        Panel1.Controls.Add(Button2)
        Panel1.Controls.Add(Button1)
        Panel1.Controls.Add(btnDashboard)
        Panel1.Controls.Add(Label1)
        Panel1.Controls.Add(PictureBox1)
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(246, 719)
        Panel1.TabIndex = 0
        ' 
        ' Panel2
        ' 
        Panel2.Dock = DockStyle.Right
        Panel2.Location = New Point(245, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(882, 719)
        Panel2.TabIndex = 1
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.student_removebg_preview
        PictureBox1.Location = New Point(30, 0)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(178, 165)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 1
        PictureBox1.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        Label1.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.Cyan
        Label1.Location = New Point(0, 168)
        Label1.Name = "Label1"
        Label1.Size = New Size(247, 23)
        Label1.TabIndex = 12
        Label1.Text = "STUDENT"
        Label1.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' btnDashboard
        ' 
        btnDashboard.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        btnDashboard.BackColor = Color.Transparent
        btnDashboard.BackgroundImageLayout = ImageLayout.None
        btnDashboard.FlatAppearance.BorderSize = 0
        btnDashboard.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(179), CByte(57), CByte(57))
        btnDashboard.FlatStyle = FlatStyle.Flat
        btnDashboard.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        btnDashboard.ForeColor = Color.White
        btnDashboard.Image = My.Resources.Resources.icons8_dashboard_24
        btnDashboard.ImageAlign = ContentAlignment.MiddleLeft
        btnDashboard.Location = New Point(0, 205)
        btnDashboard.Name = "btnDashboard"
        btnDashboard.Size = New Size(246, 39)
        btnDashboard.TabIndex = 16
        btnDashboard.Text = "DashBoard"
        btnDashboard.UseVisualStyleBackColor = False
        ' 
        ' Button1
        ' 
        Button1.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        Button1.BackColor = Color.Transparent
        Button1.BackgroundImageLayout = ImageLayout.None
        Button1.FlatAppearance.BorderSize = 0
        Button1.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(179), CByte(57), CByte(57))
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Button1.ForeColor = Color.White
        Button1.Image = My.Resources.Resources.icons8_dashboard_24
        Button1.ImageAlign = ContentAlignment.MiddleLeft
        Button1.Location = New Point(0, 250)
        Button1.Name = "Button1"
        Button1.Size = New Size(246, 39)
        Button1.TabIndex = 17
        Button1.Text = "Exams"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        Button2.BackColor = Color.Transparent
        Button2.BackgroundImageLayout = ImageLayout.None
        Button2.FlatAppearance.BorderSize = 0
        Button2.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(179), CByte(57), CByte(57))
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Button2.ForeColor = Color.White
        Button2.Image = My.Resources.Resources.icons8_dashboard_24
        Button2.ImageAlign = ContentAlignment.MiddleLeft
        Button2.Location = New Point(0, 295)
        Button2.Name = "Button2"
        Button2.Size = New Size(246, 39)
        Button2.TabIndex = 18
        Button2.Text = "Results"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Button3
        ' 
        Button3.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        Button3.BackColor = Color.Transparent
        Button3.BackgroundImageLayout = ImageLayout.None
        Button3.FlatAppearance.BorderSize = 0
        Button3.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(179), CByte(57), CByte(57))
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Button3.ForeColor = Color.White
        Button3.Image = My.Resources.Resources.icons8_dashboard_24
        Button3.ImageAlign = ContentAlignment.MiddleLeft
        Button3.Location = New Point(0, 340)
        Button3.Name = "Button3"
        Button3.Size = New Size(246, 39)
        Button3.TabIndex = 19
        Button3.Text = "Profile"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' btnExit
        ' 
        btnExit.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        btnExit.BackColor = Color.Transparent
        btnExit.BackgroundImageLayout = ImageLayout.None
        btnExit.FlatAppearance.BorderSize = 0
        btnExit.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(179), CByte(57), CByte(57))
        btnExit.FlatStyle = FlatStyle.Flat
        btnExit.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        btnExit.ForeColor = Color.White
        btnExit.Image = My.Resources.Resources.icons8_logout_24
        btnExit.ImageAlign = ContentAlignment.MiddleLeft
        btnExit.Location = New Point(1, 657)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(246, 39)
        btnExit.TabIndex = 20
        btnExit.Text = "Logout"
        btnExit.UseVisualStyleBackColor = False
        ' 
        ' STUDENT
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1127, 719)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        Name = "STUDENT"
        StartPosition = FormStartPosition.CenterScreen
        Text = "STUDENT"
        Panel1.ResumeLayout(False)
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents btnDashboard As Button
    Friend WithEvents btnExit As Button
End Class
