﻿Public Class STUDENTREGISTRATION
    Private Sub TextBox1_MouseHover(sender As Object, e As EventArgs) Handles txtFirstname.MouseHover
        txtFirstname.BackColor = Color.Gainsboro
    End Sub

    Private Sub TxtFirstname_MouseLeave(sender As Object, e As EventArgs) Handles txtFirstname.MouseLeave
        txtFirstname.BackColor = Color.White
    End Sub

    Private Sub txtLastname_MouseHover(sender As Object, e As EventArgs) Handles txtLastname.MouseHover
        txtLastname.BackColor = Color.Gainsboro
    End Sub

    Private Sub txtLastname_MouseLeave(sender As Object, e As EventArgs) Handles txtLastname.MouseLeave
        txtLastname.BackColor = Color.White
    End Sub

    Private Sub txtMiddlename_MouseHover(sender As Object, e As EventArgs) Handles txtMiddlename.MouseHover
        txtMiddlename.BackColor = Color.Gainsboro
    End Sub

    Private Sub txtMiddlename_MouseLeave(sender As Object, e As EventArgs) Handles txtMiddlename.MouseLeave
        txtMiddlename.BackColor = Color.White
    End Sub

    Private Sub txtEmail_MouseHover(sender As Object, e As EventArgs) Handles txtEmail.MouseHover
        txtEmail.BackColor = Color.Gainsboro
    End Sub

    Private Sub txtEmail_MouseLeave(sender As Object, e As EventArgs) Handles txtEmail.MouseLeave
        txtEmail.BackColor = Color.White
    End Sub

    Private Sub txtContact_MouseHover(sender As Object, e As EventArgs) Handles txtContact.MouseHover
        txtContact.BackColor = Color.Gainsboro
    End Sub

    Private Sub txtContact_MouseLeave(sender As Object, e As EventArgs) Handles txtContact.MouseLeave
        txtContact.BackColor = Color.White
    End Sub
End Class