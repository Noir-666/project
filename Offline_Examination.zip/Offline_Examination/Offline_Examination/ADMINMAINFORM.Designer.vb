﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ADMINMAINFORM
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        Panel3 = New Panel()
        lblTotalStudent = New Label()
        Panel2 = New Panel()
        lblTotalCourse = New Label()
        Panel1.SuspendLayout()
        Panel2.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.Controls.Add(lblTotalStudent)
        Panel1.Location = New Point(31, 32)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(202, 119)
        Panel1.TabIndex = 0
        ' 
        ' Panel3
        ' 
        Panel3.Location = New Point(477, 32)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(202, 119)
        Panel3.TabIndex = 1
        ' 
        ' lblTotalStudent
        ' 
        lblTotalStudent.AutoSize = True
        lblTotalStudent.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTotalStudent.Location = New Point(11, 12)
        lblTotalStudent.Name = "lblTotalStudent"
        lblTotalStudent.Size = New Size(93, 15)
        lblTotalStudent.TabIndex = 0
        lblTotalStudent.Text = "Total Students :"
        ' 
        ' Panel2
        ' 
        Panel2.Controls.Add(lblTotalCourse)
        Panel2.Location = New Point(256, 32)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(202, 119)
        Panel2.TabIndex = 1
        ' 
        ' lblTotalCourse
        ' 
        lblTotalCourse.AutoSize = True
        lblTotalCourse.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTotalCourse.Location = New Point(11, 12)
        lblTotalCourse.Name = "lblTotalCourse"
        lblTotalCourse.Size = New Size(86, 15)
        lblTotalCourse.TabIndex = 0
        lblTotalCourse.Text = "Total Courses :"
        ' 
        ' ADMINMAINFORM
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(757, 436)
        Controls.Add(Panel2)
        Controls.Add(Panel3)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        Name = "ADMINMAINFORM"
        StartPosition = FormStartPosition.CenterScreen
        Text = "ADMINMAINFORM"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents lblTotalStudent As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents lblTotalCourse As Label
End Class
